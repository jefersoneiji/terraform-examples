export const handler = async (event) => {
    return "Hello, World from Terraform!"
   };
   